from django.db import connection


def createScoreTable():
    stmt = """
            CREATE TABLE Scores (
                institution CHAR(20) NOT NULL,
                score INTEGER NOT NULL,
                PRIMARY KEY (institution)
            );
            """
    cursor = connection.cursor()
    print(stmt)
    cursor.execute(stmt)


def checkManagerCreditentials(m_username, m_password):
    stmt = "SELECT username, password FROM DatabaseManager WHERE username='"+m_username+"' AND password='"+m_password+"';"
    cursor = connection.cursor()
    print(stmt)
    cursor.execute(stmt)
    tmp = cursor.fetchall()
    if len(tmp) == 0:
        return False
    return True


def checkValidityOfNewUser(u_username, u_institution):
    stmt = "SELECT username, institution FROM User WHERE username='"+u_username+"' AND institution='"+u_institution+"';"
    cursor = connection.cursor()
    cursor.execute(stmt)
    tmp = cursor.fetchall()
    if len(u_username) == 0 or len(u_institution) == 0:
        return False
    if len(tmp) == 0:
        return True
    return False


def checkReaction(reaction_id):
    stmt = "SELECT reaction_id FROM BindingDB WHERE reaction_id='"+reaction_id+"';"
    print(stmt)
    cursor = connection.cursor()
    cursor.execute(stmt)
    tmp = cursor.fetchall()
    if len(tmp) == 0:
        return False
    return True


def addNewUser(username, institution, password):
    stmt = "INSERT INTO User (username, institution, password) values ('"+username+"','"+institution+"','"+password+"');"
    print(stmt)
    cursor = connection.cursor()
    cursor.execute(stmt)


def update_affinity(reaction_id, new_value):
    stmt = "UPDATE BindingDB SET affinity_nM = "+new_value+" WHERE reaction_id = '"+reaction_id+"';"
    print(stmt)
    cursor = connection.cursor()
    cursor.execute(stmt)


def viewDrugs():
    stmt = "SELECT * FROM DrugBank;"
    cursor = connection.cursor()
    cursor.execute(stmt)
    tmp = cursor.fetchall()
    content = []
    for s in tmp:
        x = {"drugbank_id":s[0], "name":s[1], "drug_interactions":s[2], "description":s[3]}
        content.append(x)    
    return content


def viewProteins():
    stmt = "SELECT * FROM UniProt;"
    cursor = connection.cursor()
    print(stmt)
    cursor.execute(stmt)
    tmp = cursor.fetchall()
    content = []
    for s in tmp:
        x = {"uniprot_id":s[0], "prot_sequence":s[1]}
        content.append(x)    
    return content



def viewSides():
    stmt = "SELECT * FROM SIDER;"
    cursor = connection.cursor()
    print(stmt)
    cursor.execute(stmt)
    tmp = cursor.fetchall()
    content = []
    for s in tmp:
        x = {"umlscui":s[0], "drugbank_id":s[1], "side_effect_name":s[2]}
        content.append(x)    
    return content


def viewDrugInteractions():
    stmt = "SELECT drug_interactions FROM DrugBank;"
    cursor = connection.cursor()
    print(stmt)
    cursor.execute(stmt)
    tmp = cursor.fetchall()
    content = []
    for s in tmp:
        x = {"drug_interactions":s[0]}
        content.append(x)    
    return content



def viewPaperCont():
    stmt = "SELECT doi, authors FROM BindingDB;"
    cursor = connection.cursor()
    print(stmt)
    cursor.execute(stmt)
    tmp = cursor.fetchall()
    content = []
    for s in tmp:
        x = {"doi":s[0], "authors":s[1]}
        content.append(x)    
    return content


def viewUsers():
    stmt = "SELECT * FROM USER;"
    cursor = connection.cursor()
    print(stmt)
    cursor.execute(stmt)
    tmp = cursor.fetchall()
    content = []
    for s in tmp:
        x = {"username":s[0], "institution":s[1], "password":s[2]}
        content.append(x)    
    return content


def deleteProtein(id):
    stmt = "DELETE FROM UniProt WHERE uniprot_id="+id+";"
    cursor = connection.cursor()
    print(stmt)
    cursor.execute(stmt)
    tmp = cursor.fetchall()
    return True


def deleteDrug(id):
    stmt = "DELETE FROM DrugBank WHERE drugbank_id="+id+";"
    cursor = connection.cursor()
    print(stmt)
    cursor.execute(stmt)
    tmp = cursor.fetchall()   
    return True