from django import forms

class ManagerLoginForm(forms.Form):
    username = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'username'}))
    password = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'password'}))

class AffinityForm(forms.Form):
    reaction_id = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'reaction id'}))
    new_value = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'new affinity value'}))

class DrugForm(forms.Form):
    drugbank_id = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'drugbank id'}))

class ProteinForm(forms.Form):
    uniprot_id = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'uniprot_id'}))

class SideEffectForm(forms.Form):
    umls_cui = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'umls_cui'}))

class KeywordForm(forms.Form):
    keyword = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'keyword'}))