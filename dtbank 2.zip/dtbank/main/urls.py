from main.dbmanagers.manager_functions import viewDrugs, viewSides
from django.urls import path
from . import views

urlpatterns = [
    path("", views.home, name="home"),

    path("db_manager_login/", views.db_loginIndex, name="db_loginIndex"),
    path("db_manager_login/#", views.db_manager_login, name="db_manager_login"),
    path("manager_operations/", views.mngOperations, name="manager_operations"),
    path("manager_operations/add_user", views.db_manager_add_user_index, name="add_user_index"),
    path("manager_operations/add_user/#", views.db_manager_add_user, name="add_user"),
    path("manager_operations/update_affinity", views.db_manager_update_affinity_index, name="update_affinity_index"),
    path("manager_operations/update_affinity/#", views.db_manager_update_affinity, name="update_affinity"),
    path("manager_operations/view_all_drugs", views.db_manager_view_all_drugs, name="view_all_drugs"),
    path("manager_operations/view_all_proteins", views.db_manager_view_all_proteins, name="view_all_proteins"),
    path("manager_operations/view_all_side_effects", views.db_manager_view_all_side_effects, name="view_all_sides"),
    path("manager_operations/view_all_interactions", views.db_manager_view_all_interactions, name="view_all_inter"),
    path("manager_operations/view_all_papers_and_cont", views.db_manager_view_all_papers_and_cont, name="view_all_paper_conts"),
    path("manager_operations/view_all_users", views.db_manager_view_all_users, name="view_all_users"),




    path('user_login/', views.user_loginIndex, name='user_loginIndex'),
    path('user_login/#', views.user_login, name='user_login'),
    path('user_operations/', views.userOperations, name='operation'),
    path("user_operations/view_all_drugs", views.user_view_all_drugs, name="view_all_drugs"),
    path("user_operations/view_drug_interactions", views.user_view_drug_interactions_index, name="view_drug_interactions_index"),
    path("user_operations/view_drug_interactions/#", views.user_view_drug_interactions, name="view_drug_interactions"),
    path("user_operations/view_drug_side_effects", views.user_view_drug_side_effects_index, name="view_drug_side_effects_index"),
    path("user_operations/view_drug_side_effects/#", views.user_view_drug_side_effects, name="view_drug_side_effects"),
    path("user_operations/view_drug_targets", views.user_view_drug_targets_index, name="view_drug_targets_index"),
    path("user_operations/view_drug_targets/#", views.user_view_drug_targets, name="view_drug_targets"),
    path("user_operations/view_protein_interactions", views.user_view_protein_interactions_index, name="view_protein_interactions_index"),
    path("user_operations/view_protein_interactions/#", views.user_view_protein_interactions, name="view_protein_interactions"),
    path("user_operations/view_drugs_same_protein", views.user_view_drugs_same_protein, name="view_drugs_same_protein"),
    path("user_operations/view_proteins_same_drug", views.user_view_proteins_same_drug, name="view_proteins_same_drug"),
    path("user_operations/view_drugs_specific_side", views.user_view_drugs_specific_side_index, name="view_drugs_specific_side_index"),
    path("user_operations/view_drugs_specific_side/#", views.user_view_drugs_specific_side, name="view_drugs_specific_side"),
    path("user_operations/view_drugs_include_keyword", views.user_view_drugs_include_keyword_index, name="view_drugs_include_keyword_index"),
    path("user_operations/view_drugs_include_keyword/#", views.user_view_drugs_include_keyword, name="view_drugs_include_keyword"),
    

]