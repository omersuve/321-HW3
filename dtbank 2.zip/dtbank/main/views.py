from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpResponseRedirect
from .users.userForm import UserLoginForm
from .dbmanagers.managerForm import *
from main.users.user_functions import *
from main.dbmanagers.manager_functions import *
from werkzeug.security import generate_password_hash

#from .forms import CreateNewList

# Create your views here.

def home(response):
    #createScoreTable()
    return render(response, "main/home.html", {})


def mngOperations(request):
    return render(request, 'main/manager_operations.html', {})


def db_loginIndex(request):
    context = {"login_fail": False, "login_form":ManagerLoginForm()}    
    return render(request, 'main/manager_login.html', context)


def db_manager_login(request):
    username = str(request.POST.get("username"))
    password = str(request.POST.get("password"))
    #password = generate_password_hash(password_nohashed, method='sha256')
    
    loginCheck = checkManagerCreditentials(username, password)
    if(loginCheck):
        request.session['username'] = username
        return redirect('/manager_operations')
    context = {"login_fail": True, "login_form":ManagerLoginForm()}    
    return render(request, 'main/manager_login.html', context)


def db_manager_add_user_index(request):
    context = {"add_success": False, "already_registered": False, "login_form":UserLoginForm()}    
    return render(request, 'main/manager_add_user.html', context)


def db_manager_add_user(request):
    username = str(request.POST.get("username"))
    institution = str(request.POST.get("institution"))
    password = str(request.POST.get("password"))
    #password = generate_password_hash(password_nohashed, method='sha256')
    
    loginCheck = checkValidityOfNewUser(username, institution)

    if(loginCheck):
        addNewUser(username, institution, password)
        context = {"add_success": True, "already_registered": False, "login_form":UserLoginForm()}
        return render(request, 'main/manager_add_user.html', context)
    context = {"add_success": False, "already_registered": True, "login_form":UserLoginForm()}    
    return render(request, 'main/manager_add_user.html', context)


def db_manager_update_affinity_index(request):
    context = {"add_success": False, "add_fail": False, "login_form":AffinityForm()}
    return render(request, 'main/manager_update_affinity.html', context)


def db_manager_update_affinity(request):
    reaction_id = str(request.POST.get("reaction_id"))
    new_value = str(request.POST.get("new_value"))

    checkid = checkReaction(reaction_id)

    if(checkid):
        update_affinity(reaction_id, new_value)
        context = {"add_success": True, "add_fail": False, "login_form":AffinityForm()}
        return render(request, 'main/manager_update_affinity.html', context)
    context = {"add_success": False, "add_fail": True, "login_form":AffinityForm()}    
    return render(request, 'main/manager_update_affinity.html', context)


def db_manager_view_all_drugs(request):
    context = {"data":viewDrugs()}
    return render(request, 'main/manager_views.html', context)


def db_manager_view_all_proteins(request):
    content = {"data": viewProteins()}
    return render(request, 'main/manager_views.html', content)


def db_manager_view_all_side_effects(request):
    content = {"data": viewSides()}
    return render(request, 'main/manager_views.html', content)


def db_manager_view_all_interactions(request):
    content = {"data": viewDrugInteractions()}
    return render(request, 'main/manager_views.html', content)


def db_manager_view_all_papers_and_cont(request):
    content = {"data": viewPaperCont()}
    return render(request, 'main/manager_views.html', content)


def db_manager_view_all_users(request):
    content = {"data": viewUsers()}
    return render(request, 'main/manager_views.html', content)




def userOperations(request):
    return render(request, 'main/user_operations.html', {})


def user_loginIndex(request):
    context = {"login_fail": False, "login_form":UserLoginForm()}    
    return render(request, 'main/user_login.html', context)


def user_login(request):
    username = str(request.POST.get("username"))
    institution = str(request.POST.get("institution"))
    password = str(request.POST.get("password"))
    #password = generate_password_hash(password_nohashed, method='sha256')
    
    loginCheck = checkUserCreditentials(username, institution, password)
    if(loginCheck):
        request.session['username'] = username
        return redirect('/user_operations')
    context = {"login_fail": True, "login_form":UserLoginForm()}    
    return render(request, 'main/user_login.html', context)


def user_view_all_drugs(request):
    context = {"data":viewAllDrugs()}
    return render(request, 'main/user_views.html', context)


def user_view_drug_interactions_index(request):
    context = {"type": 0, "login_fail": False, "login_form":DrugForm()}   
    return render(request, 'main/user_views_drug.html', context)


def user_view_drug_interactions(request):
    drugbank_id = str(request.POST.get("drugbank_id"))
    check = checkDrug(drugbank_id)
    
    if(check):
        context = {"type": 0, "login_fail": False, "login_form":DrugForm(),
                    "data": viewSpecificDrugInteractions(drugbank_id)} 
        print(viewSpecificDrugInteractions(drugbank_id))
        return render(request, 'main/user_views.html', context)
    context = {"type": 0, "login_fail": True, "login_form":DrugForm()}    
    return render(request, 'main/user_views_drug.html', context)


def user_view_drug_side_effects_index(request):
    context = {"type": 1, "login_fail": False, "login_form":DrugForm()}   
    return render(request, 'main/user_views_drug.html', context)


def user_view_drug_side_effects(request):
    drugbank_id = str(request.POST.get("drugbank_id"))
    check = checkDrug(drugbank_id)
    
    if(check):
        context = {"type": 1, "login_fail": False, "login_form":DrugForm(),
                    "data": viewSpecificDrugSideEffects(drugbank_id)}
        return render(request, 'main/user_views.html', context)
    context = {"type": 1, "login_fail": True, "login_form":DrugForm()}    
    return render(request, 'main/user_views_drug.html', context)


def user_view_drug_targets_index(request):
    context = {"type": 2, "login_fail": False, "login_form":DrugForm()}   
    return render(request, 'main/user_views_drug.html', context)


def user_view_drug_targets(request):
    drugbank_id = str(request.POST.get("drugbank_id"))
    check = checkDrug(drugbank_id)
    
    if(check):
        context = {"type": 2, "login_fail": False, "login_form":DrugForm(), 
                    "data": viewSpecificDrugTargets(drugbank_id)} 
        return render(request, 'main/user_views.html', context)
    context = {"type": 2, "login_fail": True, "login_form":DrugForm()}    
    return render(request, 'main/user_views_drug.html', context)


def user_view_protein_interactions_index(request):
    context = {"login_fail": False, "login_form":ProteinForm()}   
    return render(request, 'main/user_views_protein.html', context)


def user_view_protein_interactions(request):
    uniprot_id = str(request.POST.get("uniprot_id"))
    check = checkProtein(uniprot_id)
    
    if(check):
        context = {"login_fail": False, "login_form":ProteinForm(),
                    "data": viewSpecificProteinInteractions(uniprot_id)} 
        return render(request, 'main/user_views.html', context)
    context = {"login_fail": True, "login_form":ProteinForm()}    
    return render(request, 'main/user_views_protein.html', context)


def user_view_drugs_same_protein(request):
    context = {"data": viewDrugsAffectSameProtein()} 
    return render(request, 'main/user_views.html', context)


def user_view_proteins_same_drug(request):
    context = {"data": viewProteinsBindSameDrug()} 
    return render(request, 'main/user_views.html', context)


def user_view_drugs_specific_side_index(request):
    context = {"login_fail": False, "login_form":SideEffectForm()}   
    return render(request, 'main/user_views_side.html', context)


def user_view_drugs_specific_side(request):
    umls_cui = str(request.POST.get("umls_cui"))
    check = checkSideEffect(umls_cui)
    
    if(check):
        context = {"login_fail": False, "login_form":SideEffectForm(),
                    "data": viewDrugsSpecificSideEffect(umls_cui)}
        return render(request, 'main/user_views.html', context)
    context = {"login_fail": True, "login_form":SideEffectForm()}    
    return render(request, 'main/user_views_side.html', context)


def user_view_drugs_include_keyword_index(request):
    context = {"login_fail": False, "login_form":KeywordForm()}   
    return render(request, 'main/user_views_keyword.html', context)


def user_view_drugs_include_keyword(request):
    keyword = str(request.POST.get("keyword"))
    content = viewDrugsIncludeKeyword(keyword)
    if(content):
        context = {"login_fail": False, "login_form":KeywordForm(),
                    "data": viewDrugsIncludeKeyword(keyword)}
        return render(request, 'main/user_views.html', context)
    context = {"login_fail": True, "login_form":KeywordForm()}
    return render(request, 'main/user_views_keyword.html', context)


def user_view_DOI_author(request):
    context = {"data": viewDOIAuthor()}   
    return render(request, 'main/user_views.html', context)