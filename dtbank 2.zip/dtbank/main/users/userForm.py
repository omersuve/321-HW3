from django import forms

class UserLoginForm(forms.Form):
    username = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'username'}))
    institution = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'institution'}))
    password = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'password'}))