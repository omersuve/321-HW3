from django.db import connection

def checkUserCreditentials(u_username, u_institution, u_password):
    stmt = "SELECT username, institution, password FROM User WHERE username='"+u_username+"' AND institution='"+u_institution+"' AND password='"+u_password+"';"
    cursor = connection.cursor()
    print(stmt)
    cursor.execute(stmt)
    tmp = cursor.fetchall()
    if len(tmp) == 0:
        return False
    return True


def checkDrug(drugbank_id):
    stmt = "SELECT drugbank_id FROM DrugBank WHERE drugbank_id='"+drugbank_id+"';"
    print(stmt)
    cursor = connection.cursor()
    cursor.execute(stmt)
    tmp = cursor.fetchall()
    if len(tmp) == 0:
        return False
    return True


def checkProtein(uniprot_id):
    stmt = "SELECT uniprot_id FROM UniProt WHERE uniprot_id ='"+uniprot_id+"';"
    cursor = connection.cursor()
    cursor.execute(stmt)
    tmp = cursor.fetchall()
    if len(tmp) == 0:
        return False
    return True


def checkSideEffect(umls_cui):
    stmt = "SELECT umls_cui FROM SIDER WHERE umls_cui ='"+umls_cui+"';"
    cursor = connection.cursor()
    cursor.execute(stmt)
    tmp = cursor.fetchall()
    if len(tmp) == 0:
        return False
    return True


def viewAllDrugs():
    stmt = """SELECT D.drug_name, D.drugbank_id, B.smiles, D.drug_description, B.target_name, S.side_effect_name
              FROM DrugBank D, BindingDB B, SIDER S
              WHERE D.drugbank_id = B.drugbank_id AND D.drugbank_id = S.drugbank_id ;"""""
    cursor = connection.cursor()
    print(stmt)
    cursor.execute(stmt)
    tmp = cursor.fetchall()
    content = []
    for s in tmp:
        x = {"name":s[0], "drugbank_id":s[1], "smiles":s[2], "description":s[3], "target_name":s[4], "side_effect_name":s[5]}
        content.append(x)    
    return content


# def viewDrugNames():
#     stmt = """SELECT D.name
#               FROM DrugBank D;"""""
#     cursor = connection.cursor()
#     print(stmt)
#     cursor.execute(stmt)
#     tmp = cursor.fetchall()
#     content = []
#     for s in tmp:
#         x = {"name":s[0]}
#         content.append(x)    
#     return content


# def viewDrugIDs():
#     stmt = """SELECT D.drugbank_id
#               FROM DrugBank D;"""
#     cursor = connection.cursor()
#     print(stmt)
#     cursor.execute(stmt)
#     tmp = cursor.fetchall()
#     content = []
#     for s in tmp:
#         x = {"drugbank_id":s[0]}
#         content.append(x)    
#     return content


# def viewDrugSmiles():
#     stmt = """SELECT B.smiles
#               FROM DrugBank D, BindingDB B
#               WHERE D.drugbank_id == B.drugbank_id;"""
#     cursor = connection.cursor()
#     print(stmt)
#     cursor.execute(stmt)
#     tmp = cursor.fetchall()
#     content = []
#     for s in tmp:
#         x = {"smiles":s[0]}
#         content.append(x)    
#     return content


# def viewDrugDesc():
#     stmt = """SELECT D.description
#               FROM DrugBank D, SIDER S
#               WHERE D.drugbank_id == S.drugbank_id;"""
#     cursor = connection.cursor()
#     print(stmt)
#     cursor.execute(stmt)
#     tmp = cursor.fetchall()
#     content = []
#     for s in tmp:
#         x = {"description":s[0]}
#         content.append(x)    
#     return content


# def viewDrugTargets():
#     stmt = """SELECT B.target_name
#               FROM DrugBank D, BindingDB B
#               WHERE D.drugbank_id == B.drugbank_id;"""
#     cursor = connection.cursor()
#     print(stmt)
#     cursor.execute(stmt)
#     tmp = cursor.fetchall()
#     content = []
#     for s in tmp:
#         x = {"target_name":s[0]}
#         content.append(x)    
#     return content


# def viewDrugSides():
#     stmt = """SELECT S.side_effect_name
#                FROM DrugBank D, SIDER S
#                WHERE D.drugbank_id == S.drugbank_id;"""
#     cursor = connection.cursor()
#     print(stmt)
#     cursor.execute(stmt)
#     tmp = cursor.fetchall()
#     content = []
#     for s in tmp:
#         x = {"side_effect_name":s[0]}
#         content.append(x)    
#     return content


def viewSpecificDrugInteractions(id):
    stmt = """SELECT D.drug_interactions
              FROM DrugBank D
              WHERE D.drugbank_id = '""" + id + "';"
    cursor = connection.cursor()
    print(stmt)
    cursor.execute(stmt)
    tmp = cursor.fetchall()
    content = []
    for s in tmp:
        x = {"drug_interactions":s[0]}
        content.append(x)    
    return content


def viewSpecificDrugSideEffects(id):
    stmt = """SELECT S.side_effect_name
              FROM DrugBank D, SIDER S
              WHERE D.drugbank_id = '""" + id + "' AND S.drugbank_id = D.drugbank_id;"
    cursor = connection.cursor()
    print(stmt)
    cursor.execute(stmt)
    tmp = cursor.fetchall()
    content = []
    for s in tmp:
        x = {"side_effect_name":s[0]}
        content.append(x)    
    return content


def viewSpecificDrugTargets(id):
    stmt = """SELECT B.target_name
              FROM DrugBank D, BindingDB B
              WHERE D.drugbank_id = '""" + id + "' AND D.drugbank_id = B.drugbank_id;"
    cursor = connection.cursor()
    print(stmt)
    cursor.execute(stmt)
    tmp = cursor.fetchall()
    content = []
    for s in tmp:
        x = {"target_name":s[0]}
        content.append(x)    
    return content


def viewSpecificProteinInteractions(id):
    stmt = """SELECT D.drugbank_id, D.drug_name
              FROM DrugBank D, BindingDB B, UniProt U
              WHERE U.uniprot_id = '""" + id + "' AND U.uniprot_id = B.uniprot_id AND D.drugbank_id = B.drugbank_id;"
    cursor = connection.cursor()
    print(stmt)
    cursor.execute(stmt)
    tmp = cursor.fetchall()
    content = []
    for s in tmp:
        x = {"drugbank_id":s[0], "name":s[1]}
        content.append(x)    
    return content


def viewDrugsAffectSameProtein():
    stmt = """SELECT D.drugbank_id, D.drug_name
              FROM DrugBank D, BindingDB B, UniProt U
              WHERE U.uniprot_id = B.uniprot_id AND D.drugbank_id = B.drugbank_id
              GROUP BY B.uniprot_id;"""
    cursor = connection.cursor()
    print(stmt)
    cursor.execute(stmt)
    tmp = cursor.fetchall()
    content = []
    for s in tmp:
        x = {"drugbank_id":s[0], "name":s[1]}
        content.append(x)    
    return content


def viewProteinsBindSameDrug():
    stmt = """SELECT U.uniprot_id
              FROM DrugBank D, BindingDB B, UniProt U
              WHERE U.uniprot_id = B.uniprot_id AND D.drugbank_id = B.drugbank_id
              GROUP BY D.drugbank_id;"""
    cursor = connection.cursor()
    print(stmt)
    cursor.execute(stmt)
    tmp = cursor.fetchall()
    content = []
    for s in tmp:
        x = {"uniprot_id":s[0]}
        content.append(x)    
    return content


def viewDrugsSpecificSideEffect(umls_cui):
    stmt = """SELECT D.drugbank_id, D.drug_name
              FROM DrugBank D, SIDER S
              WHERE S.umls_cui = '""" + umls_cui + "' AND S.drugbank_id = D.drugbank_id;"
    cursor = connection.cursor()
    print(stmt)
    cursor.execute(stmt)
    tmp = cursor.fetchall()
    content = []
    for s in tmp:
        x = {"drugbank_id":s[0], "name":s[1]}
        content.append(x)    
    return content


def viewDrugsIncludeKeyword(keyword):
    stmt = """SELECT D.drugbank_id, D.drug_name
              FROM DrugBank D
              WHERE D.drug_description LIKE CONCAT('%','""" +keyword+ """','%');"""
    cursor = connection.cursor()
    print(stmt)
    cursor.execute(stmt)
    tmp = cursor.fetchall()
    content = []
    for s in tmp:
        x = {"drugbank_id":s[0], "name":s[1]}
        content.append(x)
    return content


def viewDrugsWithLeastSides(id):
    stmt = """
              SELECT D.drugbank_id
              FROM DrugBank D, Uniprot U, BindingDB B
              WHERE B.uniprot_id == U.uniprot_id AND B.drugbank_id == D.drugbank_id AND U.uniprot_id == """ + id + """;
        
              SELECT res.circuit_type, T.short_name, res.max_occ
FROM Teams T, (SELECT *
                FROM (SELECT Tr.lap_recorder, T.team_id, COUNT(S.drugbank_id) AS cnt, Tr.circuit_type
                        FROM Tracks Tr, SIDER S
                        WHERE
                            T.driver_one = Tr.lap_recorder OR
                            T.driver_two = Tr.lap_recorder
                        GROUP BY drugbank_id) AS t, (SELECT team_id, circuit_type, MIN(cnt) AS min_occ
                                                                FROM (SELECT Tr.lap_recorder, T.team_id, COUNT(T.team_id) AS cnt, Tr.circuit_type
                                                                    FROM Tracks Tr, Teams T
                                                                    WHERE
                                                                        T.driver_one = Tr.lap_recorder OR
                                                                        T.driver_two = Tr.lap_recorder
                                                                    GROUP BY team_id, circuit_type) AS t
                                                                GROUP BY circuit_type) AS d
                WHERE t.circuit_type = d.circuit_type AND cnt = min_occ
                ) AS res
WHERE T.team_id = res.team_id
              
              """
              


    # S.drugbank_id == D.drugbank_id AND B.drugbank_id == D.drugbank_id AND B.uniprot_id == U.uniprot_id AND 
    cursor = connection.cursor()
    print(stmt)
    cursor.execute(stmt)
    tmp = cursor.fetchall()
    content = []
    for s in tmp:
        x = {"drugbank_id":s[0], "name":s[1]}
        content.append(x)    
    return content


def viewDOIAuthor():
    stmt = """SELECT B.doi, B.authors
              FROM BindingDB B;"""
    cursor = connection.cursor()
    print(stmt)
    cursor.execute(stmt)
    tmp = cursor.fetchall()
    content = []
    for s in tmp:
        x = {"doi":s[0], "authors":s[1]}
        content.append(x)    
    return content